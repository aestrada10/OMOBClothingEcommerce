[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-8d59dc4de5201274e310e4c54b9627a8934c3b88527886e3b421487c677d23eb.svg)](https://classroom.github.com/a/I5DP-Kdb)
# CSE330

Aldo Estrada 479178 aestrada10

***Creative Project Description and Rubric***
---------------------------------------------

For my creative project, I have decided to create an e-commerce website using Django, Javascript, HTML, and CSS.

**Rubric Turned In On Time (5 PTS)**

Approved by Riley Haffner - 4/5/2023, 3:28 PM


**Learned/Used Frameworks (20 PTS)** 

20 Pts: Learned Django Full Stack 

0 Pts: Javascript Front-End

0 Pts: HTML Front-End

0 Pts: CSS Front-End 

**Functionality (60 PTS)** 

5 PTS - Users can create an account, login, and logout

5 PTS - Uses CRSF Tokens to maintain users carts and orders 

10 PTS - Users can add to cart, update cart, or checkout their carts

10 PTS - Users can select and look at different store products 

10 PTS - Database contains appropriate links, products, and purchases to maintain functionality within the store 

20 PTS - Users can checkout products using Paypal integration 

**Coding Best Practices (5 PTS)**

3 PTS - Code is well formatted and easy to understand 

2 PTS - All Pages Pass HTML Validator 

**Creative Portion (10 PTS)**

10 PTS - Users can add to a guest cart and check out as a guest without having to create an account 



